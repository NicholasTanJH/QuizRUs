const swconf = {
  
    cacheName: 'chirpy-1744736950',resources: [
      '/assets/css/jekyll-theme-chirpy.css',
      '/',
      
        '/Major-Features/',
      
        '/video-tutorial/',
      
        '/Our-Team/',
      
        '/Postmortem/',
      

      
      
    ],

    interceptor: {paths: [
        
      ],urlPrefixes: [
        
      ]
    },

    purge: false
  
};

